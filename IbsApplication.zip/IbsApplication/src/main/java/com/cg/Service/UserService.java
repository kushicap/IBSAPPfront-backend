package com.cg.Service;


import java.util.List;




import com.cg.Exception.UserProfileAlreadyExistsException;
import com.cg.Model.UserProfile;



public interface UserService {
	public UserProfile addUserProfile(UserProfile userprofile) throws UserProfileAlreadyExistsException;
	public List<UserProfile> getAllUserProfile();
	public UserProfile getUserProfileByuserName(String userName);
	public UserProfile getUserProfileBydeleted(String deleted);
	public UserProfile getUserProfileByuserId(String userId);
//	public UserProfile getUserProfileBysso(int sso);
	
	

}
