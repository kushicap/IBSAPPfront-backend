package com.cg.Service;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Service;

import com.cg.Exception.UserProfileAlreadyExistsException;
import com.cg.Model.UserProfile;
import com.cg.Repository.UserRepository;
@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private UserRepository userRepo;
	@Autowired
	private MongoRepository<UserProfile, String> userprofilerepository;
	//paramerized Constructor
	
	public UserServiceImpl(UserRepository userRepo) {
		super();
		this.userRepo = userRepo;
	}
	@Override
	public UserProfile addUserProfile(UserProfile userprofile) throws UserProfileAlreadyExistsException {
		// TODO Auto-generated method stub
		if(userRepo.existsById(userprofile.getUserId())) {
			throw new UserProfileAlreadyExistsException();
		}
		LocalDateTime now = LocalDateTime.now();
//		Date date = new Date(); 
		userprofile.setDate(now);
		
		UserProfile saveduserprofile = userRepo.save(userprofile);
		return saveduserprofile;
	}

	

	@Override
	public List<UserProfile> getAllUserProfile() {
		// TODO Auto-generated method stub
		List<UserProfile> userprofile = userprofilerepository.findAll();
        System.out.println("Getting data from DB : " + userprofile);
        return userprofile;
	}

	@Override
    public UserProfile getUserProfileByuserName(String userName) {
//       
		return userRepo.findByUserName(userName);
	}
	@Override
	public UserProfile getUserProfileBydeleted(String deleted) {
	 //TODO Auto-generated method stub
		return userRepo.findByDeleted(deleted);
		
	}
	@Override
	public UserProfile getUserProfileByuserId(String userId) {
		// TODO Auto-generated method stub
		return userRepo.findByUserId(userId);
	}
//	@Override
//	public UserProfile getUserProfileBysso(int sso) {
//		// TODO Auto-generated method stub
//		return userRepo.findBySSo(sso);
//	}
	
}


