package com.cg.Controller;

import java.util.List;



import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.cg.Exception.UserProfileAlreadyExistsException;
import com.cg.Model.UserProfile;
import com.cg.Service.UserService;

@RestController
@RequestMapping("/api/v1")

public class UserController {
	@Autowired
	private UserService userServ;
	@Autowired
	public UserController(UserService userServ) {
			this.userServ = userServ;
	}
	@CrossOrigin(origins="http://localhost:4200")
	//to add values
		@PostMapping("/addUser")
		 public ResponseEntity<UserProfile> addUserProfile(@Valid @RequestBody UserProfile userprofile ) throws UserProfileAlreadyExistsException{
			UserProfile saveduserprofile = userServ.addUserProfile(userprofile);
	        return new ResponseEntity<>(saveduserprofile, HttpStatus.CREATED);
	    }
	
	
		//To get the data from Userprofile
	@CrossOrigin(origins="http://localhost:4200")
		 @GetMapping("/findallUserProfile")
		    public ResponseEntity<List<UserProfile>> getAllUserProfile(){
		        return new ResponseEntity<List<UserProfile>>((List<UserProfile>)userServ.getAllUserProfile(),HttpStatus.OK);
		    }
//		 @CrossOrigin(origins="http://localhost:4200")
		 
        //To get the data from UserProfile by using Username
		 @GetMapping("/getUserProfile/{userName}")

		 public UserProfile getUserProfileByuserName(@PathVariable String userName) {
			 return userServ.getUserProfileByuserName(userName);
	        }
		//To get the data from UserProfile by using deleted
		 @GetMapping("/getdeleted/{deleted}")
		 public UserProfile getUserProfileBydeleted(@PathVariable String deleted) {
			 return userServ.getUserProfileBydeleted(deleted);
	        }
//		 @GetMapping("/getdeleted/{deleted}")
//	        public ResponseEntity < UserProfile > getUserProfileBydeleted(@PathVariable String deleted)throws NameNotFoundException  {
//	            return ResponseEntity.ok().body(userServ.getUserProfileBydeleted(deleted));
//	        }
		 @CrossOrigin(origins="http://localhost:4200")
		 @GetMapping("/getUserid/{userId}")
		 public UserProfile getUserProfileByuserId(@PathVariable String userId) {
			 return userServ.getUserProfileByuserId(userId);
	        }
//		 @GetMapping("/getSso/{sso}")
//		 public UserProfile getUserProfileBysso(@RequestBody UserProfile userprofile,@PathVariable("sso") int sso) {
//			 return userServ.getUserProfileBysso(sso);
//	        }
 
}
