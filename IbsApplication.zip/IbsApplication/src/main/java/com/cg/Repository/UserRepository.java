package com.cg.Repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.cg.Model.UserProfile;

public interface UserRepository extends MongoRepository<UserProfile, String> {
	UserProfile findByUserName(String username);


	UserProfile findByDeleted(String deleted);


	UserProfile findByUserId(String userId);
//	UserProfile findBySSo(int sso);


}
