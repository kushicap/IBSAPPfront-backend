package com.cg.Model;

import java.time.LocalDateTime;
import java.util.Date;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
//POJO Class
@Document(collection="UserProfile")
public class UserProfile {
	@Id//Primary key
	@Length(max = 5)//it should didn't exceed more than 5values
	@NotNull//the field must not be not null
private String userId;
private String userName;
private int sso;
private String e2ibs;
private String bct;
private String similarGroup;
private String extractGroup;
private String deleted;
private LocalDateTime date;

//Default Constructor
public UserProfile() {
	super();
	// TODO Auto-generated constructor stub
}

//Parameterized Constructor
public UserProfile(@Length(max = 5) @NotNull String userId, String userName, int sso, String e2ibs, String bct,
		String similarGroup, String extractGroup, String deleted, LocalDateTime date) {
	super();
	this.userId = userId;
	this.userName = userName;
	this.sso = sso;
	this.e2ibs = e2ibs;
	this.bct = bct;
	this.similarGroup = similarGroup;
	this.extractGroup = extractGroup;
	this.deleted = deleted;
    this.date = date;
}



//Setters and Getters
public String getUserId() {
	return userId;
}

public void setUserId(String userId) {
	this.userId = userId;
}

public String getUserName() {
	return userName;
}

public void setUserName(String userName) {
	this.userName = userName;
}

public int getSso() {
	return sso;
}

public void setSso(int sso) {
	this.sso = sso;
}

public String getE2ibs() {
	return e2ibs;
}

public void setE2ibs(String e2ibs) {
	this.e2ibs = e2ibs;
}

public String getBct() {
	return bct;
}

public void setBct(String bct) {
	this.bct = bct;
}

public String getSimilarGroup() {
	return similarGroup;
}

public void setSimilarGroup(String similarGroup) {
	this.similarGroup = similarGroup;
}

public String getExtractGroup() {
	return extractGroup;
}

public void setExtractGroup(String extractGroup) {
	this.extractGroup = extractGroup;
}

public String getDeleted() {
	return deleted;
}

public void setDeleted(String deleted) {
	this.deleted = deleted;
}

public LocalDateTime getDate() {
	return date;
}

public void setDate(LocalDateTime date) {
//	Date date = new Date(); 
//	date=LocalDateTime.now();
	this.date = date;
}

//tostring()

@Override
public String toString() {
	return "UserProfile [userId=" + userId + ", userName=" + userName + ", sso=" + sso + ", e2ibs=" + e2ibs + ", bct="
			+ bct + ", similarGroup=" + similarGroup + ", extractGroup=" + extractGroup + ", deleted=" + deleted
			+ ", date=" + date + "]";
}
}
