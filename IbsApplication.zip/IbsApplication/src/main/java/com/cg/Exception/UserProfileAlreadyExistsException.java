package com.cg.Exception;

public class UserProfileAlreadyExistsException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UserProfileAlreadyExistsException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserProfileAlreadyExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
		
	}
}
