package com.cg;

import org.junit.jupiter.api.Test;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IbsApplicationTests {

	@Test
	void contextLoads() {
		IbsApplication.main(new String[] {});
	}

}
