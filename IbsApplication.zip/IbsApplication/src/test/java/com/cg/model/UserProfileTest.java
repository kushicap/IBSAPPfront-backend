package com.cg.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.cg.Model.UserProfile;

class UserProfileTest {
private UserProfile user;
@BeforeEach //used before current test cases
public void preConfig() {
user= new UserProfile();
user.setUserId("REDW9");
user.setUserName("Ali");
user.setSso(46276543);
}
	@Test
	public void FavTest() {
		UserProfile user = Mockito.mock(UserProfile.class);
	assertNotNull(user,"Success");
	
	}
	
	
	@Test
	public void FavUserTestSuccess() {
	assertEquals(user.getUserId(),"REDW9");
	assertEquals(user.getUserName(),"Ali");
	assertEquals(user.getSso(),46276543);
	}
	



}
