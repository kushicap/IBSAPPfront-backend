package com.cg.repository;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;


//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;

import com.cg.Model.UserProfile;
import com.cg.Repository.UserRepository;
@SpringBootTest


class UserRepositoryTest {
	@Autowired
	private UserRepository userRepo;
	//UserProfile must return User object data
	
		@Test
		public void givenUserProfileShouldReturnUserProfileObject() {

			//			Date d=new Date();
		
			
			UserProfile user = new UserProfile("Akh1","Akhil", 563890," "," ","S99999","ECFUST","no",null);//user Input
			userRepo.save(user);//data saved into database
			UserProfile users= userRepo.findById(user.getUserId()).get();//fetching the data from database
			assertNotNull(users);//to check if its returning the user object data
			assertEquals(user.getUserName(),users.getUserName());
		}



}
