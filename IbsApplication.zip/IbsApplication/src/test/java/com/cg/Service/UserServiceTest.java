package com.cg.Service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.Exception.UserProfileAlreadyExistsException;
import com.cg.Model.UserProfile;
import com.cg.Repository.UserRepository;


@SpringBootTest
@ExtendWith(MockitoExtension.class)
class UserServiceTest {
	@Mock //It makes test code & verification error easier to read
	private UserRepository Us;
	@InjectMocks //mark a field on which an injection is to be performed.
	private UserServiceImpl Usl;
	

	@Test
	public void TestAddUserProfile() throws UserProfileAlreadyExistsException {
		UserProfile user = new UserProfile("Akh1","Akhil", 563890," "," ","S99999","ECFUST","no",null);
		when(Us.save(any())).thenReturn(user);//data saved into database and returns the data
		Usl.addUserProfile(user);
		verify(Us,times(1)).save(any());//the method was called one times
	}
    

   
}