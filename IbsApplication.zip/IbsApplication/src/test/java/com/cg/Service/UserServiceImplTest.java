package com.cg.Service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.Exception.UserProfileAlreadyExistsException;
import com.cg.Model.UserProfile;
import com.cg.Repository.UserRepository;

import org.junit.jupiter.api.Assertions;
@SpringBootTest

class UserServiceImplTest {

	@Autowired
	private UserServiceImpl impl;
	@Autowired
	private UserService userservice;
	 

	@Test
	void UserAlreadyExist() throws UserProfileAlreadyExistsException {
		UserProfile userprofile = new UserProfile();
		userprofile.setUserId("vahi2");
		userprofile.setUserName("Vahida");
		userprofile.setSso(4563210);

		
		
		Assertions.assertThrows(UserProfileAlreadyExistsException.class, () -> impl.addUserProfile(userprofile));
	}
	@Test
	public void whenValidName_thenUserProfileShouldBeFound() {
	    String userName = "Akhil";
	    UserProfile found = userservice.getUserProfileByuserName(userName);
	 
	     assertThat(found.getUserName())
	      .isEqualTo(userName);// if username found and is equal to user data
	     
	 }


}
