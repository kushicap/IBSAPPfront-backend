package com.cg.Controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import static org.assertj.core.api.Assertions.assertThat;
import com.cg.Model.UserProfile;
import com.cg.Service.UserService;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(MockitoExtension.class)

class UserControllerTest {
	@Autowired
	private MockMvc mocMvc;

	@Mock//It makes test code &verification error easier
	private UserService Us;
	private UserProfile U;
	private List<UserProfile> Userlist;
	@InjectMocks//mark a field on which an injection is to be performed.
	private UserController Ac;
	@BeforeEach //used before current test cases
	public void setUp() {
	U = new UserProfile("Akh1","Akhil", 563890," "," ","S99999","ECFUST","no",null);
	mocMvc= MockMvcBuilders.standaloneSetup(Ac).build();
	}
	@Test//tells JUnit that this public void method to which it is attached can be run as a test case
	public void UserControllerTest() throws Exception{
	when(Us.addUserProfile(any())).thenReturn(U);
	mocMvc.perform(post("/api/v1/addUser")
	.contentType(MediaType.APPLICATION_JSON)
	.content(asJSONString(U)))
	.andExpect(status().isCreated());
	verify(Us,times(1)).addUserProfile(any());//the method was called one times
	
	}
	@Test
	public void getAllUserProfileControllerTest() throws Exception  {
	when(Us.getAllUserProfile()).thenReturn(Userlist);
	mocMvc.perform(MockMvcRequestBuilders.get("/api/v1/findallUserProfile")
	.contentType(MediaType.APPLICATION_JSON)
	.content(asJSONString(U)))
	.andDo(MockMvcResultHandlers.print());
	verify(Us,times(1)).getAllUserProfile();//the method was called one times


	}

	

	public static String asJSONString(final Object obj) {
		// TODO Auto-generated method stub
		try {

		return new ObjectMapper().writeValueAsString(obj);
		} catch (Exception e) {
		throw new RuntimeException(e);
		}
		}


}
